<!DOCTYPE HTML>
<html>

    <head>

		<meta charset="utf-8" />

		<title> Exercice TP3 PHP</title>

    </head>



    <body>

		<h1> PDO : Connexion à une BDD MySQL </h1>

		<?php
			ini_set('display_errors', 'on');

			$serveur='localhost';
			$db='etudiants';
			$utilisateur='root';
			$mot_de_passe='';

			try
			{
				$connexion = new PDO("mysql:host=$serveur;dbname=$db",$utilisateur,$mot_de_passe);
				if ($connexion) echo 'Connexion réussie';
			}
			catch (PDOException $event)
			{
				die('Erreur :'.$event->getMessage());
			}

			$name='BOLANOS';
			$surname='Amandine';
			$phone_number='0606060606';
			$inserer="INSERT INTO etudiant(nom, prenom, telephone) VALUES ('BOLANOS','Amandine','0606060606')";

			//EXECUTER LA REQUETE
			$inserer=$connexion->exec($inserer);
		?>
		
	</body>
	
</html>